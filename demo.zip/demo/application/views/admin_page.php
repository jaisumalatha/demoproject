<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>HTML Table</h2>
 <?php 

             $this->load->helper("form","file");
             echo validation_errors();              
             echo form_open_multipart("admin/index");

             echo form_label("Branch:<br>","Branch");
             $data_val = array(
                  "" => "Select branch",
                  "A" => "SHOP A",
                  "B" => "SHOP B",
                 
                );
             echo form_dropdown('Branch', $data_val, set_value('Branch'));           
        
             echo form_submit("filterSearch", "Search");
             echo form_close();
             ?>
<table width="600" border="1" cellspacing="5" cellpadding="5">
  <tr style="background:#CCC">
    <th>Sr No</th>
    <th>chocolates</th>
    <th>Sold Status</th>
  </tr>
  <?php
  
  $i=1;
  foreach($data as $row)
  {
	  
  echo "<tr>";
  echo "<td>".$i."</td>";
  echo "<td>".$row->Shopadmin."</td>";
 if($row->Status==1){echo "<td>". "sold"."</td>";}else{echo "<td>"."Not sold"."</td>";}
 // echo "<td>".$row->email."</td>";
 // echo "<td>".$row->mobile."</td>";
  echo "</tr>";
  $i++;
  }
   ?>
  
</table>

</body>
</html>
