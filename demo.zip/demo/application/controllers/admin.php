<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
public function __construct()
	{
	parent::__construct();
	//$this->load->database();
	//$this->load->helper('url');
	$this->load->model('Admin_model');
	}
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		//$result['data']=$this->Admin_model->displayrecords(0);
		$result['data_val']=$this->Admin_model->displayrecords(0);
		//$this->load->view('admin_page',$result);
		
		 $this->load->library('form_validation');
            $this->load->model('Admin_model');

           // $this->form_validation->set_rules('Branch', 'Branch','required');
           
           if($this->form_validation->run()) {

            $result["data"] = $this->Admin_model->displayrecords();

			$this->load->view('admin_page',$result);
           // $this->load->view("view_search_results",$data); 

            }
            else
            {
			$result['data_val']=$this->Admin_model->displayrecords();
			 $result["data"] = $this->Admin_model->displayrecords();
           $this->load->view('admin_page',$result);

             }
		//$this->load->view('admin_page');
	}
}
