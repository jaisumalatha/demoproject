<?php 
   Class Admin_model extends CI_Model { 
	
      Public function __construct() { 
         parent::__construct(); 
      } 
	  function displayrecords()
		{
		$this->db->select('*');
		$this->db->from('admin');
		if($this->input->post('Branch')!=''){
		 $this->db->where_in('Branch', $this->input->post('Branch'));	
		}
		$query=$this->db->get();
		return $query->result();
		}
		
   } 
?> 